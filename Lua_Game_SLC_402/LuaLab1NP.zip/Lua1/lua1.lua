--[[
    MODULE NAME: First Lua Lab, Part 1

    FUNCTION:    Allows the user to do several math functions

    INPUTS:      keyboard

    OUTPUTS:     screen

    USAGE:
             The program will first prompt the user for which
             math operation they would like to perform
             It then gets input for the variables for each
             operation to be performed

    DESIGN NOTES:
        Requirements:
            - prompt the user to perform a math operation
            - calculate the answer from inputed variables

        Design:
            - PROMPT USER FOR OPERATION TO DO
            - READ USER VARIABLES
            - CALCULATE ANSWER
            - PRINT ANSWER
            - REPEAT UNTIL USER CHOOSES TO EXIT

    Programmed by: Noah Petrides
    Date Completed: May 30 2016
]]

function add(add1, add2)
	return add1 + add2
end
function sub(sub1, sub2)
	return sub1 - sub2
end
function mult(mult1, mult2)
	return mult1 * mult2
end
function div(div1, div2)
	return div1 / div2
end
function root(root1)
	return sqrt(root1)
end

io.write ("Welcome to NP-Calc! What would you like to do today?\n")

repeat
repeat
	io.write ("Enter one of the following:\n")
	io.write ("add, subtract, multiply, divide, squareroot or exit\n")
	choice = io.read()
	opt = true

	if choice == "squareroot" then
		io.write("Enter the number you wish to find the square root of\n")
		var1 = io.read()
	elseif choice == "exit" then
		io.write ("Thank you for using NP-Calc!\n")
	elseif choice == "add" or choice == "subtract" or choice == "multiply" or choice == "divide" then
		io.write("Enter your first number\n")
		var1 = io.read()
		io.write("Enter the second number\n")
		var2 = io.read()
	else
		io.write("Please enter a valid option\n")
		opt = false
	end
until opt == true

if choice  == "add" then
	answer = add(var1, var2)
elseif choice == "subtract" then
	answer = sub(var1, var2)
elseif choice == "multiply" then
	answer = mult(var1, var2)
elseif choice == "divide" then
	answer = div(var1, var2)
elseif choice == "squareroot" then
	answer = root(var1)
end

if choice == "exit" then
	io.write("Goodbye!\n")
else
	io.write ("Your answer is: ", answer, "!\n")
end
until choice == "exit"
return
