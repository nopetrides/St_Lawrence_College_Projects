// Irish Lotto
// Noah Petrides 09_12_2016 LIT BSc Game Design and Development
#include <iostream>
#include <cstdlib>
#include <ctime>

using namespace std;

int main() // main program executes here
{
	bool running = true; // decalaration for flag to see if the program should continue

	while (running) // main loop
	{
		int inputs[6]; // variable declaration
		int numbers[6];
		int matches = 0;
		int i;
		int j;
		char again;

		cout << "Welcome to the Irish Lotto! \n" << "Please input 6 numbers, within a range of 1-47. \n"; // user instructions

		cin >> inputs[0] >> inputs[1] >> inputs[2] >> inputs[3] >> inputs[4] >> inputs[5]; // receive integers from user

		for (i = 0; i < 6; i++) // Check to see if numbers are unique, and within range of the lotto (1-47)
		{
			for (j = 0; j <= i; j++)
			{
				if (i != j)
				{
					while (inputs[j] == inputs[i])
					{
						cout << "Duplicate numbers are not permitted, please choose another\n";
						cin >> inputs[j];
					}
				}
				while (inputs[i] > 47 || inputs[i] == 0)
				{
					cout << "Please enter number " << i + 1 << " within the appropriate range\n";
					cin >> inputs[i];
				}
			}
		}

		for (i = 0; i < 6; i++)
		{
			srand(static_cast<unsigned int>(time(0)));  // seed random number generator based on current time

			int randomNumber = rand(); // generate random number
			randomNumber += 47; // make sure random number is at least 47
			randomNumber *= (i + 1); // multiply the number so it will be different for each lottery number

			numbers[i] = (randomNumber % 47) + 1; // set the number between 1-47

			for (j = 0; j < i; j++) // check to ensure no numbers are duplicates, quick fix if they are
			{
				if (i != j)
				{
					if (numbers[j] == numbers[i])
						numbers[j] ++;
				}
			}
			cout << "Number " << i + 1 << " is " << numbers[i] << endl; // output the numbers to the screen
		}
		

		for (i = 0; i < 6; i++) // check to see if any of the user's numbers match the random ones
		{
			for (j = 0; j < 6; j++)
			{
				if (inputs[i] == numbers[j])
					matches++; // count up all the matching numbers
			}

		}

		if (matches == 6) // if they managaed to match all the numbers, output a special message
			cout << "Congratulations, you've won the Irish Lotto!";
		else // otherwise tell them how many (if any) numbers the matched
			cout << "Numbers matched: " << matches << "\nYou must match all numbers to win the jackpot\n\n";
		
		cout << "Enter \"y\" to play again. Other entries will quit this program.\n"; // ask user if they would like to try again

		cin >> again; // receive input from user

		if (again == 'y') // re-run the program if they enter 'y'
			running = true;
		else // stop the program loop
			running = false;
	}

	return 0; // exit succesfully
}