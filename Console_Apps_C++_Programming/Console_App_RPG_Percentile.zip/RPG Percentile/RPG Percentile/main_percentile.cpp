// RPG Percentile Dice Simulator
// Noah Petrides 09_12_2016 LIT BSc Game Design and Development

#include <iostream> //precompiler necessary for program functions
#include <cstdlib>
#include <ctime>

using namespace std;

int main() // main program executes here
{
	bool running = true; // variable declaration
	char input;

	cout << "This program rolls two ten sided die, the first representing tens (red), the second ones (green), and displays the final total\n"; // Details for user

	while (running)
	{
		srand(static_cast<unsigned int>(time(0)));  // seed random number generator based on current time

		int randomNumber = rand() % 10; // generate random number

		srand(static_cast<unsigned int>(time(0)) * 7); // second random number (multiplied seven to get second random number)
		int randomNumber2 = rand() % 10;

		int die_1 = (randomNumber) * 10; // first number is between 0 and 90 by tens
		int die_2 = (randomNumber2) + 1; // second number is between 1 and 9

		cout << "You rolled " << die_1 << " on the red die and " << die_2 << " on the green die\n" << "Your total roll is " << die_1 + die_2 << endl; // Output rolls to user

		cout << "\nTo roll again, enter \"y\" other entries will quit this program \n"; // continue message
		cin >> input; // get input from user (single character)
		if (input == 'y') // if the user inputed y, everything is good, rerun the program
			running = true;
		else
			running = false; // stop the program if the user didn't enter 'y'
	}
	return 0; // quit successfully
}
