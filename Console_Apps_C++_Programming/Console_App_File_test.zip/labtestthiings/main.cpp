



// ===================================================================

// Game203.cpp : Defines the entry point for the console application.

//

//

// - What the program does

// This demonstrates how to read and write multiple records to/from

// a database, output the results to the screen, and check for

// duplicates in the db before deciding to write.  It also shows how to

// prompt a user for enough input to fill one record of data.

//

// - Inputs

// none

// - Outputs

// Console screen display

//

// Rob Kilbride, St. Lawrence College, GAME203

// Jan 22, 2013

//

// ====================================================================


#include "string.h"

#include <cstdio>

#include <cstdlib>

#include <cstring>

#include <iostream>

using namespace std;



#define MAX_RECORD_LEN 256 // a default maximum size for strings in a customer record

#define MAX_RECORDS 100  // maximum number of records possible in this database



// This is one record for a single customer

struct eCustomerRecord

{

    eCustomerRecord()

    {

        m_nAgeInYears = 0;

        strcpy(m_strFirstName, "---");

        strcpy(m_strLastName, "---");

        strcpy(m_strEmail, "---");

        strcpy(m_strPhone, "---");

    }

    int m_nAgeInYears;

    char m_strFirstName[MAX_RECORD_LEN];

    char m_strLastName[MAX_RECORD_LEN];

    char m_strEmail[MAX_RECORD_LEN];

    char m_strPhone[MAX_RECORD_LEN];


};



// Our array of available record slots

eCustomerRecord g_aRecords[MAX_RECORDS];

// Number of records actually in this database

int g_nNumberOfRecords = 0;





// ===================================================================

// ReadAllRecords

//

//

// - What the function does

// reads all records in from disk and store in an array

//

// - Inputs

//  pass in a filename with a path to read from

//

// - Outputs

// returns a return value of pass or fail

//

// ====================================================================

int ReadAllRecords(char* strFilename)

{

    FILE *fp = NULL;



    fp = fopen(strFilename,"rb");

    if (fp)

    {

        g_nNumberOfRecords = fread(&g_aRecords,sizeof(eCustomerRecord),MAX_RECORDS,fp);



        printf("Read in %d records from the file %s\n", g_nNumberOfRecords, strFilename);



        fclose(fp);

    }

    else

    {

        g_nNumberOfRecords = 0;

        printf("Failed to open file for reading - assuming file doesn't exist\n");

    }

    return g_nNumberOfRecords;

}



// ===================================================================

// writerec

//

//

// - What the function does

// writes a record to disk, by either creating the new file or

// appending to the end of the file

//

// - Inputs

//  pass in a filename with a path to read from

//  pass in which record we'll save it in

//

// - Outputs

// returns a return value of pass or fail

//

// ====================================================================

int  writerec(char* strFilename, eCustomerRecord* pRecord)

{

    FILE *fp;

    int retval = 0;



    // If no records, create a new file, else append to the file

    if (g_nNumberOfRecords == 0)

        fp = fopen(strFilename,"wb");

    else

        fp = fopen(strFilename,"ab");



    if (fp && pRecord)

    {

        int nRecordsWritten = fwrite(pRecord,sizeof(eCustomerRecord),1,fp);

        if (nRecordsWritten > 0)

        {

            printf("Record written\n");

            retval = 1;

        }

        else

        {

            perror("FWRITE");

            printf("Record NOT written\n");

        }

        fclose(fp);

    }

    else

        printf("Failed to open file for writing\n");

    return(retval);

}



// ===================================================================

// promptrec

//

//

// - What the function does

// prompts the user to enter data in to the database

//

// - Inputs

//  pass in a pointer to a record to be filled in

//

// - Outputs

// returns pRecord filled in with the data you input

//

// ====================================================================

void promptrec(eCustomerRecord* pRecord)

{

    if (!pRecord)

        return;



    cout << "Enter your first name:" << endl;

    cin >> pRecord->m_strFirstName;

    cout << "Enter your last name:" << endl;

    cin >> pRecord->m_strLastName;

    cout << "Enter your phone number" << endl;

    cin >> pRecord->m_strPhone;

    cout << "Enter your email:" << endl;

    cin >> pRecord->m_strEmail;

    cout << "Enter your age:" << endl;

    char strAge[100];

    cin >> strAge;

    pRecord->m_nAgeInYears = atoi(strAge);

}



// ===================================================================

// DisplayRecord

//

//

// - What the function does

// displays a specific record at a given index into our g_aRecords array

//

// - Inputs

//  int i = the index into the g_aRecords array

//

// - Outputs

// bool - true or false based on if successfully found index in array

//

// ====================================================================

bool DisplayRecord(int i)

{

    if (i >= g_nNumberOfRecords || i >= MAX_RECORDS)

        return false; // out of range



    cout << "############################################" << endl;

    cout << "RECORD #" << i+1 << endl;

    cout << "FNAME: " << g_aRecords[i].m_strFirstName << endl;

    cout << "LNAME: " << g_aRecords[i].m_strLastName << endl;

    cout << "PHONE: " << g_aRecords[i].m_strPhone << endl;

    cout << "EMAIL: " << g_aRecords[i].m_strEmail << endl;

    cout << "AGE: " << g_aRecords[i].m_nAgeInYears << endl;



    return true;

}



// ===================================================================

// DisplayAllRecords

//

//

// - What the function does

// displays all records stored in our array to the screen

//

// - Inputs

//  none

//

// - Outputs

// none - writes to screen only

//

// ====================================================================

void DisplayAllRecords()

{

    cout << "Our current database:" << endl;

    for (int i=0; i<g_nNumberOfRecords; i++)

    {

        DisplayRecord(i);

    }

    cout << "############################################" << endl;

    cout << "Number of records: " << g_nNumberOfRecords << endl;

    cout << "############################################" << endl;



}



// ===================================================================

// IsRecordInDatabase

//

//

// - What the function does

// loops through our database array to see if a given record already

// exists in the database.

//

// Here's where the code gets specific.  We'll use a combination of the

// first and last name as the search key.  You'll see that in relational

// databases, we're likely to get fancier and have a unique key

//

// - Inputs

//  pointer to the new record to examine

//

// - Outputs

// index into the array if found, or -1 if not found

//

// ====================================================================

int IsRecordInDatabase(eCustomerRecord* pRecord)

{

    if (!pRecord)

        return -1;



    for (int i=0; i<g_nNumberOfRecords; i++)

    {

        if (strcmp(g_aRecords[i].m_strFirstName, pRecord->m_strFirstName) == 0 &&

                strcmp(g_aRecords[i].m_strLastName,  pRecord->m_strLastName) == 0)

        {

            return i;

        }

    }

    return -1;

}



int main()
{

    // Read in all records from disk and store in our global array, g_aRecords

    // NOTE there may be no records the first time we attempt this

    ReadAllRecords("mydb.txt");



    // Prompt user to enter info about themselves, stores in local variable, eNewRecord
    char answer;
    bool done = false;
    while (!done)
    {
        cout << "Enter r for records, n for new record or x to exit \n";
        cin >> answer;

        if (answer == 'x')
            done = true;
        else if (answer == 'r')
            DisplayAllRecords();
        else if (answer == 'n')
        {

            eCustomerRecord eNewRecord;

            promptrec(&eNewRecord);



            // Check if record exists in database, if not, returns -1

            int nRecordIndex = IsRecordInDatabase(&eNewRecord);



            if (nRecordIndex >= 0)

            {

                cout << "Found this record in the database!" << endl;

                DisplayRecord(nRecordIndex);





            }
            else

            {

                // Write this new record out to disk by either creating a new file or

                // appending to existing file

                writerec("mydb.txt", &eNewRecord);



                // Read in all records from disk again and store in our array

                ReadAllRecords("mydb.txt");



                // Output contents of the g_aRecords data array to screen

                DisplayAllRecords();

            }
        }
    }
    return 0;

}
