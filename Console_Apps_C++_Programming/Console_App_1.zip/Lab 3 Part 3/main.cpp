#include <iostream> // Allows for inputs and outputs
#include <windows.h>

using namespace std; // Set the usage of standard names

int main()           // Activiates "main"
{
    int count;       // Declaring "count"
    int spaces;      // Declaring "spaces"
    count = 78;      // Sets "count"s value to 78
    while (count>1)  // Tests to see if count is greater than 1
    {
        spaces = 1;  // Setting "spaces"s value to 1

        while (spaces<count)        // Tests to see if "spaces" is smaller than "count"
        {
            cout << " ";            // Displays a space
            spaces++;               // Adds 1 to "spaces"
        }
        cout << "A " << "\r";       // Displays "A " and returns to the start of the line
        count--;                    // Minus's 1 from "count"
        Sleep(300);                 // Waits for 300 milliseconds
    }
    return 0;                       // Exits
}
