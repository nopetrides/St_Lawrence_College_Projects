// main.cpp : Defines the entry point for the console application.
// Noah Petrides 09/08/2016 - First day of Game Programming at LIT

#include <iostream>
#include <string>
using namespace std;

int main()
{
	cout << "Enter first and last name" << endl; //Instructions print to screen
	string first; //Declare two string variables
	string second; //See above
	cin >> first >> second; //Get two vars from user
	string name = first + " " + second; //Concatanate string
	cout << "Good to meet you, " << name << "!" << endl; //Output to user
	return 0; //Exit program
}

