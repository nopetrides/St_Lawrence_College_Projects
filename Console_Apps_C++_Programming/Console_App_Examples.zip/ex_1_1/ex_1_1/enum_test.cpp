#include <iostream>
#include <string>
using namespace std;

int main()
{
	enum difficulty {NOVICE, EASY, NORMAL, HARD, UNBEATABLE};

	cout << "Please choose level of difficulty\n";
	cout << "NOVICE = 0, EASY = 1, NORMAL = 2, HARD = 3, UNBEATABLE = 4 \n";

	difficulty MyDifficulty;
	int input = NULL;

	cin >> input;

	while (input > 4)
	{
		cout << "invalid entry, please enter a number between 0 and 4 \n";
		cin >> input;
	}

	MyDifficulty = difficulty(input);

	cout << "Thank you! Difficulty has been set to ";
	if (input == 0)
		cout << "NOVICE";
	else if (input == 1)
		cout << "EASY";
	else if (input == 2)
		cout << "NORMAL";
	else if (input == 3)
		cout << "HARD";
	else if (input == 4)
		cout << "UNBEATABLE";
	cout << endl;
	enum shipCost {Fighter_Cost = 25, Bomber_Cost = 50};

	int loot = 500;

	cout << "\nYou have " << loot << " gold before ship cost \n";

	cout << "Please choose a ship type \n";
	cout << "Fighter = 0 (cost 25g), Bomber = 1 (cost 50g), \n";

	input = NULL;

	cin >> input;

	while (input > 1)
	{
		cout << "invalid entry, please enter a number between 0 and 1 \n";
		cin >> input;
	}

	shipCost MyShipCost = shipCost(input);

	

	if (input == 0)
		loot = loot - Fighter_Cost;
	else
		loot = loot - Bomber_Cost;

	cout << "You have " << loot << " gold after ship cost \n";

	return 0;

}