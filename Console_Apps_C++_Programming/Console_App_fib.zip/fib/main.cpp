#include <iostream>

using namespace std;

int fib( int num)
{
    int retval;

    if (num>1)
    {
        retval = fib(num-1) + fib(num-2);

    }
    else
    {
        retval = num;

    }
    return(retval);
}

/*



*/
int fib_iterate( int num)
{
    int retval;
    int sum=1;
    int i;
    int last1=0;
    int last2=0;

    for (i=1;i<num;i++)
    {
        last2 = last1;
        last1 = sum;
        sum = last1 + last2;
    }
    return(sum);

}



int main()
{
    int i;

    for (i=1;i<10;i++)
    {
        cout << "RECURSIVE NUM=" << i << "   FIB(i)= " << fib(i) << endl;
    }
    for (i=1;i<10;i++)
    {
        cout << "ITERATIVE " << fib_iterate(i) << endl;
    }
    return 0;
}
