/*

    Game development sample class usage program using
    Allegro.

    The class PICT was created to allow programmers to
    easily create and animate images

    The sample program is BAREBONE code which animates
    3 hardwired objects (with the same image) in different
    directions.

*/

#include <stdio.h>
#include <stdlib.h>
#include "allegro5/allegro.h"
#include "allegro5/allegro_image.h"


int SCR_W;   // To hold display dimensions
int SCR_H;


int image_x = 0;
int image_y = 0;
int d_x = 1;
int d_y = 1;
int image_height;
int image_width;


class PICT
{
public:
    float x,y;    // Position on the screen of pict
    float dx, dy; // Velocity of the pict
    ALLEGRO_BITMAP *image;
    ALLEGRO_BITMAP *vimage;
    int b_x_r;   // Bounce right on screen
    int b_x_l;   // Bounce left on screen
    int b_y_u;   // Bounce up on screen
    int b_y_d;   // Bounce down on screen

    char pictname[128];

    PICT(const char filename[]="", float cx=0, float cy=0, float cdx=0.0, float cdy=0.0)
    {
        x = cx;
        y = cy;
        dx = cdx;
        dy = cdy;
        strncpy(pictname,filename,128);
    }

    void load()
    {
        image =al_load_bitmap(pictname);
        if (image)
        {
            //al_convert_mask_to_alpha(image, al_map_rgb(255, 255, 255));

            al_set_new_bitmap_flags(ALLEGRO_VIDEO_BITMAP);
            vimage = al_clone_bitmap(image);
            if (!vimage)
                vimage = image;
            b_x_r = SCR_W - al_get_bitmap_width(vimage);
            b_x_l = 0;
            b_y_u = 0;
            b_y_d = SCR_H - al_get_bitmap_height(vimage);
            al_convert_mask_to_alpha(vimage, al_map_rgb(255, 255, 255));

        }
    }


    ~PICT()
    {

    }

    void display()
    {
        al_draw_bitmap(vimage, (int)x, (int) y, 0);
    }

    void move()
    {
        x += dx;
        y += dy;
        if (((x<0) && (dx<0)) ||
                ((x>b_x_r) && (dx>0)))
            dx =  -dx;
        if (((y<0) && (dy<0)) ||
                ((y>b_y_d) && (dy>0)))
            dy = -dy;
    }
};

PICT one("mysha.pcx", 200,200, 1.1,1.1);
PICT two("mysha.pcx", 400,200, -1.1,1.1);
PICT three("mysha.pcx", 150,200, -3.1,-1.1);
PICT four("mysha.pcx", 150,250, -3.1,0);

#define MAXPICTS 5
PICT all[MAXPICTS];



void abort_example(const char err_msg[])
{
    printf("Aborting: %s\n",err_msg);
    exit(1);
}



int main(int argc, const char **argv)
{
    const char *filename;
    int i;
    ALLEGRO_DISPLAY *display;
    ALLEGRO_TIMER *timer;
    ALLEGRO_EVENT_QUEUE *queue;
    bool redraw = true;

    if (argc > 1)
    {
        filename = argv[1];
    }
    else
    {
        filename = "mysha.pcx";
    }

    if (!al_init())
    {
        abort_example("Could not init Allegro.\n");
    }

    if (argc > 2)
    {
        al_set_new_display_adapter(atoi(argv[2]));
    }

    al_install_mouse();
    al_install_keyboard();

    al_init_image_addon();
    SCR_W = 800;
    SCR_H = 600;

    display = al_create_display( SCR_W, SCR_H);
    if (!display)
    {
        abort_example("Error creating display\n");
    }
    SCR_W = al_get_display_width(display);
    SCR_H = al_get_display_height(display);
    al_set_window_title(display, "C++ PICT OBJECT DEMO");

    one.load();
    two.load();
    three.load();
    four.load();
    for (i=0; i<MAXPICTS; i++)
    {
        //strcpy(all[i].pictname,"ball.pcx");
        strcpy(all[i].pictname,"nball.bmp");
        //strcpy(all[i].pictname,"mysha.pcx");
        all[i].x = rand() % SCR_W;
        all[i].y = rand() % SCR_H;
        all[i].dx = rand() % 7 - 3;
        all[i].dy = rand() % 7 - 3;
        all[i].load();

    }

    timer = al_create_timer(1.0 / 30);
    queue = al_create_event_queue();
    al_register_event_source(queue, al_get_keyboard_event_source());
    al_register_event_source(queue, al_get_display_event_source(display));
    al_register_event_source(queue, al_get_timer_event_source(timer));
    al_start_timer(timer);

    while (1)
    {

        ALLEGRO_EVENT event;
        al_wait_for_event(queue, &event);
        if (event.type == ALLEGRO_EVENT_DISPLAY_ORIENTATION)
        {
            int o = event.display.orientation;
            if (o == ALLEGRO_DISPLAY_ORIENTATION_0_DEGREES)
            {
                printf("0 degrees\n");
            }
            else if (o == ALLEGRO_DISPLAY_ORIENTATION_90_DEGREES)
            {
                printf("90 degrees\n");
            }
            else if (o == ALLEGRO_DISPLAY_ORIENTATION_180_DEGREES)
            {
                printf("180 degrees\n");
            }
            else if (o == ALLEGRO_DISPLAY_ORIENTATION_270_DEGREES)
            {
                printf("270 degrees\n");
            }
            else if (o == ALLEGRO_DISPLAY_ORIENTATION_FACE_UP)
            {
                printf("Face up\n");
            }
            else if (o == ALLEGRO_DISPLAY_ORIENTATION_FACE_DOWN)
            {
                printf("Face down\n");
            }
        }
        if (event.type == ALLEGRO_EVENT_DISPLAY_CLOSE)
            break;
        if (event.type == ALLEGRO_EVENT_KEY_CHAR)
        {
            if (event.keyboard.keycode == ALLEGRO_KEY_ESCAPE)
                break;
        }
        if (event.type == ALLEGRO_EVENT_TIMER)
            redraw = true;

        if (redraw && al_is_event_queue_empty(queue))
        {
            redraw = false;
            al_clear_to_color(al_map_rgb_f(0, 0, 0));
            one.display();
            two.display();
            three.display();
            four.display();
            for (i=0; i<MAXPICTS; i++)
            {
                all[i].display();
                all[i].move();
            }
            one.move();
            two.move();
            three.move();
            four.move();
            al_flip_display();
        }
    }
    al_destroy_display(display);

    return 0;
}

