'''
    MODULE NAME: Second Python lab Parts 1-4
    
    FUNCTION:    Allows the user to control three images, and pick between 4 songs
             
    INPUTS:      keyboard, mouse, joystick
    
    OUTPUTS:     Images in a window and audio
    
    USAGE:
             The program starts up with three images, the user can move each with a different controller
             
    DESIGN NOTES:
        Requirements:
            - Allow keyboard, mouse and joystick control for images
            - Allow user to change music with each keyboard mouse and joystick
            
        Design:
            - Draw 2d images onto screen, made up from lines and shapes
            - Play sound
            - Process input from user from keyboard, mouse and joystick
            - Update screen
            - Change songs if needed
            - Play sound on collision
            
    Programmed by: Noah Petrides
    Date Completed: February 8 2016
'''


# Import a library of functions called 'pygame'
import pygame 
import os
# Initialize the game engine
pygame.init()

#Get Current working directory
path = os.getcwd()

#sound file locations
bg1 = path + '\\' + 'braaaa.MP3'
bg2 = path + '\\' + 'Damned.mp3'
bg3 = path + '\\' + 'Lose Yourself to Dance (feat. Pharell Williams) - Daft Punk.mp3'
bg4 = path + '\\' + 'Me - The 1975.mp3'

hit = path + '\\' + 'ding.mp3'

#set starting song
music = bg1

#setup pygame mixer
pygame.mixer.init()
hitsound = pygame.mixer.Sound(hit)
pygame.mixer.music.load(music)
pygame.mixer.music.play()

# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
BLUE = (0, 0, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
change_x = 0
change_y = 0

PI = 3.141592653
 
# Set the height and width of the screen
size = (400, 500)
screen = pygame.display.set_mode(size)
 
pygame.display.set_caption("Drawing Functions")
 
# Loop until the user clicks the close button.
done = False
clock = pygame.time.Clock()

#Functions for drawing different sets of 2d images
def draw_head(screen,x,y):
    ding = False
    if x < -20:
        x = -20
        ding = True
    if y < -20:
        y = -20
        ding = True
    if x > 230:
        x = 229
        ding = True
    if y > 380:
        y = 379
        ding = True
    if ding == True:
        hitsound.play()
    pygame.draw.rect(screen, BLACK, [20 + x, 20 + y, 150, 100], 2)
    pygame.draw.rect(screen, BLACK, [45 + x, 90 + y, 100, 20], 2)
    pygame.draw.ellipse(screen, BLACK, [30 + x, 30 + y, 50, 50], 2)
    pygame.draw.ellipse(screen, BLACK, [110 + x, 30 + y, 50, 50], 2)
    
def draw_stick(screen,x,y):
    ding = False
    if x < -130:
        x = -130
        ding = True
    if y < -190:
        y = -190
        ding = True
    if x > 220:
        x = 219
        ding = True
    if y > 189:
        y = 179
        ding = True
    if ding == True:
        hitsound.play()
    pygame.draw.ellipse(screen, BLACK, [130 + x, 270 + y, 50, 50], 2)
    pygame.draw.rect(screen, BLACK, [145 + x,190 + y, 20, 100], 2)

def draw_stick_figure(screen, x, y):
    ding = False
    if x < 1:
        x = 1
        ding = True
    if y < 1:
        y = 1
        ding = True
    if x > 390:
        x = 389
        ding = True
    if y > 475:
        y = 474
        ding = True
    if ding == True:
        hitsound.play()
    # Head
    pygame.draw.ellipse(screen, BLACK, [1+x, 0+y, 10, 10], 0)
 
    # Legs
    pygame.draw.line(screen, BLACK, [5+x, 17+y], [10+x, 27+y], 2)
    pygame.draw.line(screen, BLACK, [5+x, 17+y], [0+x, 27+y], 2)
 
    # Body
    pygame.draw.line(screen, RED, [5+x, 17+y], [5+x, 7+y], 2)
 
    # Arms
    pygame.draw.line(screen, RED, [5+x, 7+y], [9+x, 17+y], 2)
    pygame.draw.line(screen, RED, [5+x, 7+y], [1+x, 17+y], 2)
 
pygame.display.set_caption("My Game")
 
# Loop until the user clicks the close button.
done = False
 
 
#Initializing the game controller for use
# Current position
x_coord = 10
y_coord = 10

# Speed in pixels per frame
x_speed = 0
y_speed = 0

hx = 0
hy = 0

jx = 0
jy = 0

jcordsx = 0
jcordsy = 0

button = [0,0,0,0]


# Count the joysticks the computer has
joystick_count = pygame.joystick.get_count()
if joystick_count == 0:
    # No joysticks!
    print("Error, I didn't find any joysticks.")
else:
    # Use joystick #0 and initialize it
    my_joystick = pygame.joystick.Joystick(0)
    my_joystick.init()
 

# Used to manage how fast the screen updates
clock = pygame.time.Clock()
 
# Hide the mouse cursor
pygame.mouse.set_visible(0)
 
# -------- Main Program Loop -----------
while not done:
    # ALL EVENT PROCESSING SHOULD GO BELOW THIS COMMENT
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
            
        if event.type == pygame.MOUSEMOTION:
            position = pygame.mouse.get_pos()
            x_coord = position[0]
            y_coord = position[1]
            
        if event.type == pygame.MOUSEBUTTONDOWN:
            if music == bg1:
                music = bg2
                pygame.mixer.music.load(music)
                pygame.mixer.music.play()
            elif music == bg2:
                music = bg3
                pygame.mixer.music.load(music)
                pygame.mixer.music.play()
            elif music == bg3:
                music = bg4
                pygame.mixer.music.load(music)
                pygame.mixer.music.play()
            elif music == bg4:
                music = bg1
                pygame.mixer.music.load(music)
                pygame.mixer.music.play()
        # User pressed down on a key
        elif event.type == pygame.KEYDOWN:
            # Figure out if it was an arrow key. If so
            # adjust speed.
            if event.key == pygame.K_LEFT:
                change_x = -3
            elif event.key == pygame.K_RIGHT:
                change_x = 3
            elif event.key == pygame.K_UP:
                change_y = -3
            elif event.key == pygame.K_DOWN:
                change_y = 3
            elif event.key == pygame.K_1:
                music = bg1
                pygame.mixer.music.load(music)
                pygame.mixer.music.play()
            elif event.key == pygame.K_2:
                music = bg2
                pygame.mixer.music.load(music)
                pygame.mixer.music.play()
            elif event.key == pygame.K_3:
                music = bg3
                pygame.mixer.music.load(music)
                pygame.mixer.music.play()
            elif event.key == pygame.K_4:
                music = bg4
                pygame.mixer.music.load(music)
                pygame.mixer.music.play()
            
        # User let up on a key
        elif event.type == pygame.KEYUP:
        # If it is an arrow key, reset vector back to zero
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                change_x = 0
            elif event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                change_y = 0
                
        elif event.type == pygame.JOYAXISMOTION:
            #Joystick motion processing
            if joystick_count != 0:
                # This gets the position of the axis on the game controller
                # It returns a number between -1.0 and +1.0
                horiz_axis_pos = my_joystick.get_axis(0)
                vert_axis_pos = my_joystick.get_axis(1)
                # Move x according to the axis. We multiply by 10 to speed up the movement.
                # Convert to an integer because we can't draw at pixel 3.5, just 3 or 4.
                jx = int(horiz_axis_pos * 10)
                jy = int(vert_axis_pos * 10)
                
        if event.type == pygame.JOYBUTTONDOWN:
            #Joystick button processing
            print "Joystick button pressed"
            for i in range(4):
                button[i] = my_joystick.get_button(i)
                if button[0] == True:
                    music = bg1
                    pygame.mixer.music.load(music)
                    pygame.mixer.music.play()
                elif button[1] == True:
                    music = bg2
                    pygame.mixer.music.load(music)
                    pygame.mixer.music.play()   
                elif button[2] == True:
                    music = bg3
                    pygame.mixer.music.load(music)
                    pygame.mixer.music.play()   
                elif button[3] == True:
                    music = bg4
                    pygame.mixer.music.load(music)
                    pygame.mixer.music.play()
                #print button
                
                
    # Move the object according to the speed vector.
    x_coord += x_speed
    y_coord += y_speed
    

    hx += change_x
    hy += change_y
    
    jcordsx += jx
    jcordsy += jy
    
    
    # ALL EVENT PROCESSING SHOULD GO ABOVE THIS COMMENT
    # This goes in the main program loop!
     
    # Clear the screen
    screen.fill(WHITE)
 
    # Draw the item at the proper coordinates
    draw_stick_figure(screen, x_coord, y_coord)
    draw_head(screen, hx, hy)
    draw_stick(screen, jcordsx, jcordsy)
 
    # Go ahead and update the screen with what we've drawn.
    pygame.display.flip()
 
    # Limit to 20 frames per second
    clock.tick(60)
 
# Close the window and quit.
pygame.quit()
