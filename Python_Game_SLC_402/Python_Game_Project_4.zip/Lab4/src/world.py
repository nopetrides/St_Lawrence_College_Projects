#!/usr/bin/env python

"""
World Module. Contains the definition of the Block object.
"""
'''
    MODULE NAME: Breakout Clone - Power Ups
    
    FUNCTION:    The function is to add PowerUps to this premade game
             
    INPUTS:      mouse
    
    OUTPUTS:     Images in a window and audio
    
    USAGE:
             The program starts up "Breakout", user can collect Power Ups.
             
    DESIGN NOTES:
        Requirements:
            - Create Power Up Class
            - Collision between paddle and Power Up
            - Player can shoot bullets with power up
            - Power Up lasts a certain amount of time
            
        Design:
            - Draw a n animated image to screen for Power Up
            - Collision
            - On collision change player paddle
            - 10 second timer on Power Up
            - Shootable Bullets
            
    Programmed by: Noah Petrides
    Date Completed: March 23 2016
'''

#Import Modules
import pygame
from lab_helpers import *
from event_helper import *
from block import *
from paddle import *
from ball import *
from PowerUp import *
from gunnerpaddle import *
from Bullets import *
from pygame.examples.midi import null_key
from threading import Timer
import gunnerpaddle

# Game constants
DATAPATH = 'data'
SCREENRECT = pygame.Rect(0, 0, 372, 480)

class World():
    '''
    World object class.
    Represents the game world in this BreakOut clone.
    This class will be charged with creating the game world, including the game window
    and initializing it with the blocks, the paddle and the ball.
    This call will also handle the main update loop including handling event,
    drawing the images, updating the objects and collision detection.
    '''

    # Class attributes
    gamescreen = None
    master_sprite_sheet = None
    background = None
    
    
    def __init__(self):
        '''
        Create the game window and display it on screen.
        Initialize the list of game objects needed for blocks, ball and the paddle.
        '''
        
        # Initialize Pygame and window.
        pygame.init()
        World.gamescreen = pygame.display.set_mode(SCREENRECT.size)
        pygame.display.set_caption('BreakCloneNP')
        
        # set the background
        World.background = pygame.Surface(SCREENRECT.size)
        World.background.fill((0,0,100))
        World.gamescreen.blit(World.background, (0, 0))
        pygame.display.flip()

        # Load the sprite sheet
        master_sprite_sheet = SpriteSheet(DATAPATH, "breakout_master.bmp")

        # Assign the source block images to the Block class
        Block.source_images = master_sprite_sheet.get_images([(225, 193, 31, 16),
                                                           (225, 225, 31, 16),
                                                           (225, 257, 31, 16),
                                                           (225, 289, 31, 16),
                                                           (257, 193, 31, 16),
                                                           (257, 225, 31, 16),
                                                           (257, 257, 31, 16),
                                                           (257, 289, 31, 16)])

        # Set up the groups needed for all the game objects
        self.block_group = pygame.sprite.Group()
        self.ball_group = pygame.sprite.Group()
        self.paddle_group = pygame.sprite.Group()
        self.gunnerpaddle_group = pygame.sprite.Group()
        self.powerup_group = pygame.sprite.Group()
        self.render_group = pygame.sprite.RenderUpdates()
        self.bullet_list = pygame.sprite.Group()


        # Create the paddle
        self.gamepaddle = Paddle(master_sprite_sheet, (SCREENRECT.centerx, SCREENRECT.bottom - 30), SCREENRECT, self.paddle_group, self.render_group)
        self.gunnerpaddle = GunnerPaddle(master_sprite_sheet, (SCREENRECT.centerx, SCREENRECT.bottom - 30), SCREENRECT, self.gunnerpaddle_group, self.render_group)

        # Add the ball
        Ball(master_sprite_sheet, self.gamepaddle, SCREENRECT, self.ball_group, self.render_group)
        
        # Add the PowerUp
        self.poweruppos = PowerUp(master_sprite_sheet, self.gamepaddle, self.powerup_group, self.render_group)
        

        self.bullets = Bullet(self.bullet_list, self.render_group)
        # initialize the mouse
        pygame.mouse.set_visible(0)
        pygame.event.set_grab(True)

        self.PowerMove = False

    def load_level(self):
        '''
        This will set up our game, placing the bricks.
        '''
        level = [[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3, -1],
				[-1,  7,  7,  7,  7,  7,  7,  7,  7,  7,  7, -1],
				[-1,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3, -1],
				[-1,  7,  7,  7,  7,  7,  7,  7,  7,  7,  7, -1],
				[-1,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3, -1],
				[-1,  7,  7,  7,  7,  7,  7,  7,  7,  7,  7, -1],
				[-1,  3,  3,  3,  3,  3,  3,  3,  3,  3,  3, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1],
				[-1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1, -1]]
        
        
        for ytile_index in range(len(level)):
            for xtile_index in range(len(level[ytile_index])):
                colour = level[ytile_index][xtile_index]
                if colour > -1:
                    Block((xtile_index, ytile_index), colour, self.block_group, self.render_group)
                    
        self.gunning = False
        self.alt_fire = False
        

        
    def update_event(self, event):
        '''
        Forwards the important events to the game objects.
        '''
        if self.gunning == True:    
            for self.gunnerpaddle in self.gunnerpaddle_group.sprites():
                self.gunnerpaddle.on_event(event)
            if event.type == pygame.MOUSEBUTTONDOWN:
                # Fire a bullet if the user clicks the mouse button
                bullet = Bullet(self.bullet_list, self.render_group)
                # Set the bullet so it is where the player is
                if self.alt_fire == True:
                    bullet.rect.x = self.gamepaddle.rect.x
                    self.alt_fire = False
                elif self.alt_fire == False:
                    bullet.rect.x = self.gamepaddle.rect.x + 41
                    self.alt_fire = True
                bullet.rect.y = self.gamepaddle.rect.y
                # Add the bullet to the lists
                self.bullet_list.add(bullet)
        else:
            self.gunnerpaddle.rect.x = 1000       
        
        for paddle in self.paddle_group.sprites():
            paddle.on_event(event)
            
        for ball in self.ball_group.sprites():
            ball.on_event(event)
        

    def GunOff(self):
        self.gunning = False
        Ball.paddle_miss_sound.play()
        
    def update(self):
        '''
        The main update call to update the position of the game objects.
        '''
        self.ball_group.update()
        self.powerup_group.update()
        self.bullet_list.update()
        # determine when the game is over
        if len(self.block_group.sprites()) == 0:
            level_complete_event = pygame.event.Event(LEVEL_COMPLETE_EVENT)
            pygame.event.post(level_complete_event)
        
            

    def post_update(self):
        '''
        Does any post processing after the update. Most important is checking
        for collisions.
        '''
        
        # Check for collision between the ball and the paddle.
        #if self.gunning == True:
        collisions = pygame.sprite.groupcollide(self.ball_group, self.gunnerpaddle_group, False, False)
        if len(collisions):
            for ball in collisions.keys():
                ball.on_collision_detected(collisions[ball])
                
        #else:
        collisions = pygame.sprite.groupcollide(self.ball_group, self.paddle_group, False, False)
        if len(collisions):
            for ball in collisions.keys():
                ball.on_collision_detected(collisions[ball])
                
        # Check for collisions between the ball and the blocks        
        collisions = pygame.sprite.groupcollide(self.ball_group, self.block_group, False, True)
        if len(collisions):
            for ball in collisions.keys():
                ball.on_collision_detected(collisions[ball])  
                self.PowerMove = True
                self.poweruppos.velocity = [0,1]
        
        if self.PowerMove == True:
            Pcollisions = pygame.sprite.groupcollide(self.powerup_group, self.paddle_group, True, False)
            if len(Pcollisions):
                for PowerUp in Pcollisions.keys():
                    PowerUp.on_collision_detected(Pcollisions[PowerUp])
                    self.gunning = True
                    Ball.wall_collide_sound.play()
                    t = Timer(10.0, self.GunOff)
                    t.start() # after 10 seconds, gunning will be false
        
        Bcollisions = pygame.sprite.groupcollide(self.bullet_list, self.block_group, True, True)
        

            
    def update_render(self):
        '''
        '''
        self.render_group.clear(World.gamescreen, World.background)        
        dirty_rects = self.render_group.draw(World.gamescreen)
        self.powerup_group.draw(World.gamescreen)
        pygame.display.update(dirty_rects)
        
    def end_game(self):
        '''
        Does all of the end game clean up.
        '''
        pygame.quit()
    
    def run_game(self):
        # Load and setup the first level
        self.load_level()
        
        # Setup the timer for frame rate control.
        clock = pygame.time.Clock()

        # Main Loop
        while 1:

            #Handle Input Events
            for event in pygame.event.get():
                if event.type == QUIT:
                    return
                    
                elif  event.type == KEYDOWN and event.key == K_ESCAPE:
                    return
                else:
                    self.update_event(event)

            # update the world
            self.update()

            # handle any collisions post update
            self.post_update()

            # render our game
            self.update_render()
            
            # Limit the frame rate
            clock.tick(60)
