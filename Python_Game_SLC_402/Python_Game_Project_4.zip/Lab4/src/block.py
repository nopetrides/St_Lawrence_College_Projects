#!/usr/bin/env python

"""
Block Module. Contains the definition of the Block object.
"""

#Import Modules
import pygame
import random
from lab_helpers import *

data_path = '..\data'

class Block(pygame.sprite.Sprite):
    '''
    Block object class.
    Represents the breakable blocks in this BreakOut clone.
    '''

    ## Class attributes ##
    # Helpful for knowing which index relates to which colour.
    colour_code = {0 : "yellow",        1 : "green",    2: "red",
                   3 : "dark_orange",   4 : "purple",   5: "orange",
                   6 : "light_blue",    7 : "dark_blue"}
                   
    # tuple images for each block
    source_images = ()
    
    def __init__(self, tile_offset, colour_index, *groups):
        '''
        tile_offset:        offset position based on tile location to display block on screen.
        colour_index:       index in the source_image list for the block colour.
        group:              group we want to add the block to.
        
        Initializes the Sprite object and sets the image from the image sheet.
        Saves and sets the image to the desired position.
        '''
        
        pygame.sprite.Sprite.__init__(self, groups)
        self.image = Block.source_images[colour_index]
        self.rect = self.image.get_rect()
        self.rect.x = tile_offset[0] * self.rect.width
        self.rect.y = tile_offset[1] * self.rect.height
    def update(self):
        '''
        '''
        pass
