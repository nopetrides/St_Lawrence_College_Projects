#!/usr/bin/env python

"""
Ball Module. Contains the definition of the Ball object.
"""

#Import Modules
import pygame
import random, math
from lab_helpers import *
from event_helper import *
from paddle import *
from gunnerpaddle import *
from block import *

data_path = 'data'

class Ball(pygame.sprite.Sprite):
    '''
    Ball object class.
    Represents the ball used by the player to break the blocks.
    Handles movement and logic when there is a collision detected.
    '''
    default_speed = 5
    world_rect = pygame.Rect(0, 0, 1, 1)
    bounce_angle = 45
    middle_angle = 90
    
    # Iniialize the mixer. Use a lower buffer for low latency.
    pygame.mixer.init(frequency=22050, size=-16, channels=2, buffer=512)
    
    # load all the sounds
    wall_collide_sound = load_sound(data_path, "Collision8-Bit.ogg")
    block_collide_sound = load_sound(data_path, "SmallExplosion8-Bit.ogg")
    paddle_collide_sound = load_sound(data_path, "Metal_Hit.ogg")
    paddle_miss_sound = load_sound(data_path, "FreezeMagic.ogg")
    
    def __init__(self, image_sheet_surface, paddle, world_rect, *groups):
        '''
        image_sheet_surface:    surface with the loaded sprite image sheet
        startpos:               position where to display the ball image on screen.
        group:                  group we want to add the paddle to.

        Initializes the Sprite object and sets the image from the image sheet.
        Saves and sets the image to the desired position.
        Also initializes speed information
        '''
        pygame.sprite.Sprite.__init__(self, groups)
        self.image = image_sheet_surface.get_image((428, 300, 11, 11))
        self.rect = self.image.get_rect()
        self.velocity = [0, 0]
        self.paddle = paddle
        Ball.world_rect = world_rect
        
        # Set the update method to be the starting state.
        # This is equivalent to creating def update(self)
        self.update = self.update_start
        
        
    def update_start(self):
        '''
        Updates the ball's position based on current speed vector.
        '''
        self.rect.centerx = self.paddle.rect.centerx
        self.rect.bottom = self.paddle.rect.top
        

            
    def update_move(self):
        '''
        Updates the ball's position based on current speed vector.
        '''
        # Move the ball in its current direction
        self.rect.move_ip(self.velocity[0], self.velocity[1])
        
        # Check for wall collisions
        if self.rect.left < Ball.world_rect.left:
            self.rect.left = Ball.world_rect.left
            self.velocity[0] *= -1
            Ball.wall_collide_sound.play()
        elif self.rect.right > Ball.world_rect.right:
            self.rect.right = Ball.world_rect.right
            self.velocity[0] *= -1
            Ball.wall_collide_sound.play()
        
        if self.rect.top < Ball.world_rect.top:
            self.rect.top = Ball.world_rect.top
            self.velocity[1] *= -1
            Ball.wall_collide_sound.play()
        elif self.rect.top > Ball.world_rect.bottom:
            self.update = self.update_start
            Ball.paddle_miss_sound.play()
        
        
    def on_collision_detected(self, object_list):
        '''
        object_list:    represents the list of game objects the ball has collided with.
        Handles what happens when a collision is detected.
        '''
        # Initialize block collision counters
        x_collision_count = y_collision_count = 0
        # Save the current ball rect
        ball_collide_rect = self.rect     
        
        # Loop through the collided objects
        for object in object_list:
            if isinstance(object, Paddle):
                # Handle the ball bouncing off the paddle.
                # First get the ratio of where the ball is on the paddle
                # so we can have a better deflection.                
                ball_pos_ratio = (object.rect.centerx - self.rect.centerx) / (object.rect.width / 2.0)
                
                # next apply the ratio to the max bounce angle to determine if we deflect left, right
                # or straight
                tmp_angle = math.radians(Ball.middle_angle + ball_pos_ratio * Ball.bounce_angle)
                
                # use the calculated angle to determine how much we move
                # along the x and y axis.
                self.velocity[0] = math.cos(tmp_angle) * Ball.default_speed
                self.velocity[1] = -math.sin(tmp_angle) * Ball.default_speed
                
                Ball.paddle_collide_sound.play()
                
            elif isinstance (object, GunnerPaddle):
                # Handle the ball bouncing off the paddle.
                # First get the ratio of where the ball is on the paddle
                # so we can have a better deflection.                
                ball_pos_ratio = (object.rect.centerx - self.rect.centerx) / (object.rect.width / 2.0)
                
                # next apply the ratio to the max bounce angle to determine if we deflect left, right
                # or straight
                tmp_angle = math.radians(Ball.middle_angle + ball_pos_ratio * Ball.bounce_angle)
                
                # use the calculated angle to determine how much we move
                # along the x and y axis.
                self.velocity[0] = math.cos(tmp_angle) * Ball.default_speed
                self.velocity[1] = -math.sin(tmp_angle) * Ball.default_speed
                
                Ball.paddle_collide_sound.play()
                
            elif isinstance(object, Block):
                # Handle the ball bouncing off the block.
                
                # Determine which direction the ball is coming from
                if ball_collide_rect.left < object.rect.left:
                    x_collision_count += -1
                elif ball_collide_rect.right > object.rect.right:
                    x_collision_count += 1
                    
                if ball_collide_rect.top < object.rect.top:
                    y_collision_count += -1
                elif ball_collide_rect.bottom > object.rect.bottom:
                    y_collision_count += 1
                    
                Ball.block_collide_sound.play()
                    
        # Ignore direction change if collision count is zero
        if x_collision_count != 0:
            self.velocity[0] = math.copysign(self.velocity[0], x_collision_count)
        if y_collision_count != 0:
            self.velocity[1] = math.copysign(self.velocity[1], y_collision_count)
            
            
    def on_event(self, event):
        '''
        event:  Event type object describing the event.

        Handles events such as starting the ball movement.
        '''
        if event.type == pygame.MOUSEBUTTONDOWN and event.button == 1:
            # Wait for the mouse press to start the game.
            if self.update == self.update_start:
                self.velocity = [0, -Ball.default_speed]
                self.update = self.update_move
        elif event.type == LEVEL_COMPLETE_EVENT:
            self.update = self.update_start
