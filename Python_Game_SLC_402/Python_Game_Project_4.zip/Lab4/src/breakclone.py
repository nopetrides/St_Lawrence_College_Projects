#!/usr/bin/env python

"""
Main module for the Breakout clone project.
"""
'''
    MODULE NAME: Breakout Clone - Power Ups
    
    FUNCTION:    The function is to add PowerUps to this premade game
             
    INPUTS:      mouse
    
    OUTPUTS:     Images in a window and audio
    
    USAGE:
             The program starts up "Breakout", user can collect Power Ups.
             
    DESIGN NOTES:
        Requirements:
            - Create Power Up Class
            - Collision between paddle and Power Up
            - Player can shoot bullets with power up
            - Power Up lasts a certain amount of time
            
        Design:
            - Draw a n animated image to screen for Power Up
            - Collision
            - On collision change player paddle
            - 10 second timer on Power Up
            - Shootable Bullets
            
    Programmed by: Noah Petrides
    Date Completed: March 23 2016
'''


#Import Modules
import pygame
from pygame.locals import *
import world


def main():

    # Create the game world, which includes the main window
    gameworld = world.World()

    # Run the game.
    if gameworld:
        gameworld.run_game()        
        
        # Do any clean up in necessary.
        gameworld.end_game()

# This calls the 'main' function when this script is executed
if __name__ == '__main__': main()
