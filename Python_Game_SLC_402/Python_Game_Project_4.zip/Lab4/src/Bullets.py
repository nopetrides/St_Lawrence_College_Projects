'''
    MODULE NAME: Breakout Clone - Power Ups
    
    FUNCTION:    The function is to add PowerUps to this premade game
             
    INPUTS:      mouse
    
    OUTPUTS:     Images in a window and audio
    
    USAGE:
             The program starts up "Breakout", user can collect Power Ups.
             
    DESIGN NOTES:
        Requirements:
            - Create Power Up Class
            - Collision between paddle and Power Up
            - Player can shoot bullets with power up
            - Power Up lasts a certain amount of time
            
        Design:
            - Draw a n animated image to screen for Power Up
            - Collision
            - On collision change player paddle
            - 10 second timer on Power Up
            - Shootable Bullets
            
    Programmed by: Noah Petrides
    Date Completed: March 23 2016
'''

import pygame
import random

WHITE = (255, 255, 255)

class Bullet(pygame.sprite.Sprite):
    """ This class represents the bullet . """
    def __init__(self, *groups):
        # Call the parent class (Sprite) constructor
        pygame.sprite.Sprite.__init__(self, groups)
 
        self.image = pygame.Surface([4, 10])
        self.image.fill(WHITE)
 
        self.rect = self.image.get_rect()
 
    def update(self):
        """ Move the bullet. """
        self.rect.y -= 3