'''
    MODULE NAME: Breakout Clone - Power Ups
    
    FUNCTION:    The function is to add PowerUps to this premade game
             
    INPUTS:      mouse
    
    OUTPUTS:     Images in a window and audio
    
    USAGE:
             The program starts up "Breakout", user can collect Power Ups.
             
    DESIGN NOTES:
        Requirements:
            - Create Power Up Class
            - Collision between paddle and Power Up
            - Player can shoot bullets with power up
            - Power Up lasts a certain amount of time
            
        Design:
            - Draw a n animated image to screen for Power Up
            - Collision
            - On collision change player paddle
            - 10 second timer on Power Up
            - Shootable Bullets
            
    Programmed by: Noah Petrides
    Date Completed: March 23 2016
'''

import pygame
import random
from lab_helpers import *
from paddle import *
from pygame.display import flip


data_path = '..\data'

class PowerUp(pygame.sprite.Sprite):
    '''
    PowerUp object class.
    Represents the PowerUp objects in this BreakOut clone.
    '''
    source_images = ()
    
    def __init__(self, image_sheet_surface, paddle, *groups):
        '''
        tile_offset:        offset position based on tile location to display block on screen.
        colour_index:       index in the source_image list for the block colour.
        group:              group we want to add the block to.
        
        Initializes the Sprite object and sets the image from the image sheet.
        Saves and sets the image to the desired position.
        '''
        
        pygame.sprite.Sprite.__init__(self, groups)
        self.image = image_sheet_surface.get_image((5, 257, 25, 11))
        self.rect = self.image.get_rect()
        self.velocity = [0, 0]
        self.rect.x = 80
        self.rect.y = 140
        self.paddle = paddle
        
        self.images = image_sheet_surface.get_images([(5, 257, 25, 11),
                                                      (5, 289, 25, 11),
                                                      (5, 321, 25, 11),
                                                      (5, 353, 25, 11),
                                                      (5, 385, 25, 11),
                                                      (5, 193, 25, 11),
                                                      (5, 225, 25, 11)])
        self.image = self.images[0]
        poweruppos = random.randint(0, 70)


        
    def update(self):
        '''
        ''' 
        global flip
        if flip == True:
            if self.image == self.images[0]:
                self.image = self.images[1]
            elif self.image == self.images[1]:
                self.image = self.images[2]
            elif self.image == self.images[2]:
                self.image = self.images[3]
            elif self.image == self.images[3]:
                self.image = self.images[4]
            elif self.image == self.images[4]:
                self.image = self.images[5]
            elif self.image == self.images[5]:
                self.image = self.images[6]
            elif self.image == self.images[6]:
                self.image = self.images[0]
            flip = False
        else:
            flip = True
            
        self.rect.y += self.velocity[1]
    
    def on_collision_detected(self, object_list):
        '''
        objedt_list:    list of objects that have collided with the paddle, excluding the ball

        Handles collision with power-ups that fall from destroyed blocks.
        '''
        # Loop through the collided objects
        for object in object_list:
            if isinstance(object, Paddle):
               gunning = True

               
        

    def on_event(self, event):
        '''
        event:  Event type object describing the event.

        Handles events such as controlling the paddle movement
        through input from the player.
        '''
        pass
    
    def hit(self, velocitrocity):
        self.velocity = velocitrocity