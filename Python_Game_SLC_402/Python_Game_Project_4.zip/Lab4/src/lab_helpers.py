
"""
Helper module that contains useful functions that are used for the Labs.
"""

#Import Modules
import os, pygame
from pygame.locals import *

# Sound Helpers
def load_sound(path,name):
    '''
    Loads a sound a the specified path. If pygame mixer doesn't exist,
    an empty object is returned which supports the basic sound methods,
    preventing errors and allowing the game to function without sound.
    '''
    
    class NoSound:
        def play(self, loop=0): pass

    if not pygame.mixer or not pygame.mixer.get_init():
        return NoSound()

    fullname = os.path.join(path, name)
    print(fullname)

    try:
        sound = pygame.mixer.Sound(fullname)
    except pygame.error as message:
        print('Cannot load sound: {}'.format(fullname))
        raise SystemExit(message)

    return sound

def play_music(path,name):
    '''
    Sets up a music stream from the specified path and plays
    it in an infinite loop.
    '''
    
    if not pygame.mixer or not pygame.mixer.get_init():
        return None

    fullname = os.path.join(path, name)
    print(fullname)

    try:
        pygame.mixer.music.load(fullname)
        pygame.mixer.music.play(-1)
    except pygame.error as message:
        print('Cannot play music file: {}'.format(fullname))
        raise SystemExit(message)


# Background Helpers
def load_background(path, name, screen_size):
    '''
    Loads an image background and scale it to the screen size.
    '''
    
    fullname = os.path.join(path, name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load background image: {}'.format(fullname))
        raise SystemExit(message)
    image = image.convert()
    image = pygame.transform.scale(image, screen_size)
    return image


# 2D Image Helpers
def load_image(path, name, convertalpha=True, colorkey=None):
    '''
    Loads an image, and optionally applies a color key.
    Image is converted to retain current alpha values.
    '''

    fullname = os.path.join(path, name)
    try:
        image = pygame.image.load(fullname)
    except pygame.error as message:
        print('Cannot load image: {}'.format(fullname))
        raise SystemExit(message)
    if convertalpha == True:
        image = image.convert_alpha()
    else:
        image = image.convert()
    if colorkey is not None:
        if colorkey is -1:
            colorkey = image.get_at((0,0))
        image.set_colorkey(colorkey, RLEACCEL)
    return image

# Screen Print Helper
def create_text(text, size=18, colour=(0,0,0), font=None):
    '''
    Returns the surface with the rendered text.
    '''
    if pygame.font:
        font = pygame.font.Font(font, size)
        text_surface = font.render(text, 1, colour)
        return text_surface
  

# Sprite Sheet Class Helper
class SpriteSheet():
    '''
    Helper class to load a master sprite sheet as well as being able
    to create subsurfaces for one or multiple images.
    '''
    def __init__(self, datapath, filename):
        "Constructor that accepts a path and filename to load the master sheet."
        self.sheet = load_image(datapath, filename, False, (0,0,0))
        
    def get_image(self, sub_image_rect):
        "Create a subsuface at the given location on the master sprite sheet."
        return self.sheet.subsurface(sub_image_rect)

    def get_images(self, sub_image_rect_list):
        "Create a list of subsufaces at the given locations on the master sprite sheet."
        images = []
        for rect in sub_image_rect_list:
            images.append(self.get_image(rect))
        return images
        
    def get_animated_image(self, sub_image_start_rec, image_frame_offset, frame_cnt):
        " Create a list of subsurfaces at the given location and all of associated frames."
        images = []
        cur_rect = pygame.Rect(sub_image_start_rec)
        for frame in range(frame_cnt):
            cur_rect.x = sub_image_start_rec[0] + frame * image_frame_offset[0]
            cur_rect.y = sub_image_start_rec[1] + frame * image_frame_offset[1]
            images.append(self.get_image(cur_rect))
            
        return images
        
    def get_animated_images(self, sub_image_info_list):
        " Create a list of subsurfaces at the given location and all of associated frames."
        images = []
        for info in sub_image_info_list:
            images.append(self.get_animated_image(info[0], info[1], info[2]))
            
        
        return images
