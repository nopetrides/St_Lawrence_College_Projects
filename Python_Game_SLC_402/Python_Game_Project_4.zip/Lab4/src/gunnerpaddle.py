#!/usr/bin/env python

"""
Paddle Module. Contains the definition of the Paddle object.
"""

#Import Modules
import pygame
import random
from lab_helpers import *

data_path = '..\data'

class GunnerPaddle(pygame.sprite.Sprite):
    '''
    Paddle object class.
    Represents the player's paddle in this BreakOut clone.
    '''
    world_rect = None

    
    def __init__(self, image_sheet_surface, startpos, world_rect, *groups):
        '''
        image_sheet_surface:    surface with the loaded sprite image sheet        
        startpos:               position where to display the paddle image on screen.
        group:                  group we want to add the paddle to.

        Initializes the Sprite object and sets the image from the image sheet.
        Saves and sets the image to the desired position.
        '''
        pygame.sprite.Sprite.__init__(self, groups)
        # The paddle in this case is two sprite sections combined into one.
        # Therefore we create a surface large enough for the full paddle, but we blit
        # both halves onto the surface.
        self.image = pygame.Surface((43, 11)).convert_alpha()
        self.image.blit(image_sheet_surface.get_image((330, 138, 21, 11)), (0, 0))    # left half
        self.image.blit(image_sheet_surface.get_image((353, 138, 22, 11)), (21, 0))   # right half
        self.rect = self.image.get_rect()
        
        # Set the paddle's position
        self.rect.x = startpos[0] + self.rect.centerx * 10
        self.rect.y = startpos[1]
        
        # Save the world limits
        GunnerPaddle.world_rect = world_rect   


    def on_collision_detected(self, object_list):
        '''
        objedt_list:    list of objects that have collided with the paddle, excluding the ball

        Handles collision with power-ups that fall from destroyed blocks.
        '''
        pass

    def on_event(self, event):
        '''
        event:  Event type object describing the event.

        Handles events such as controlling the paddle movement
        through input from the player.
        '''
        if event.type == pygame.MOUSEMOTION:
            self.rect.centerx = event.pos[0]
            if not GunnerPaddle.world_rect.contains(self.rect):
                if self.rect.left < GunnerPaddle.world_rect.left:
                    self.rect.left = GunnerPaddle.world_rect.left
                elif self.rect.right > GunnerPaddle.world_rect.right:
                    self.rect.right = GunnerPaddle.world_rect.right
        