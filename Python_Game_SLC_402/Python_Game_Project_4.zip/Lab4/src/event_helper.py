'''
Helper Module that defines user created events for the breakout clone.
'''

import pygame
from pygame.locals import *


LEVEL_COMPLETE_EVENT = pygame.USEREVENT + 1