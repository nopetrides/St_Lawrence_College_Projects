'''
    MODULE NAME: First Python Lab, Part 2
    
    FUNCTION:    Allows the user to do several math functions
             
    INPUTS:      keyboard
    
    OUTPUTS:     screen
    
    USAGE:
             The program will first prompt the user for which
             math operation they would like to perform
             It then gets input for the variables for each
             operation to be performed
             
    DESIGN NOTES:
        Requirements:
            - prompt the user to perform a math operation
            - calculate the answer from inputed variables
            - functions must be contained within class
            
        Design:
            - PROMPT USER FOR OPERATION TO DO
            - READ USER VARIABLES
            - CALCULATE ANSWER
            - PRINT ANSWER
            - COMPLETE
            
    Programmed by: Noah Petrides
    Date Completed: January 26 2016
'''

# Class containing math functions
class MyRoutines:
    "Game 400 Lap 1 Part 2"
    pi = 3.14159
    def p_o_rec(self, length, width):
        return 2 * (length+width)

    def p_o_circ(self, radius):
        return 2 * self.pi * radius

    def a_o_rec(self, length, width):
        return length * width

    def a_o_circ(self, radius):
        return self.pi * (radius**2)

    def sa_o_cube(self, edge):
        return 6 * (edge**2)

    def sa_o_cyl(self, radius, height):
        return 2 * self.pi * radius * height + 2 * self.pi * radius

    def a_o_trap(self, a_base, b_base, height):
        return ((a_base + b_base) /2) * height

    def rec_input(self, selected):
        var1 = raw_input("Enter the length of the rectangle")
        var2 = raw_input("Enter the width of the rectangle")
        if (selected == "1"):
            answer = self.p_o_rec(float(var1), float(var2))
        if (selected == "3"):
            answer = self.a_o_rec(float(var1), float(var2))
        return answer

    def circ_input(self, selected):
        var1 = raw_input("Enter the radius of the circle")
        if (selected == "2"):
            answer = self.p_o_circ(float(var1))
        if (selected == "4"):
            answer = self.a_o_circ(float(var1))
        return answer
    
    def cube_input(self):
        var1 = raw_input("Enter the radius of the circle")
        answer = self.sa_o_cube(float(var1))
        return answer
    
    def cyl_input(self):
        var1 = raw_input("Enter the radius of the cylinder")
        var2 = raw_input("Enter the height of the cylinder")
        answer = self.sa_o_cyl(float(var1), float(var2))
        return answer
    
    def trap_input(self):
        var1 = raw_input("Enter the first base of the trapezoid")
        var2 = raw_input("Enter the second base of the trapezoid")
        var3 = raw_input("Enter the height of the trapezoid")
        answer = self.a_o_trap(float(var1), float(var2), float(var3))
        return answer

# Construct the object
DoMath = MyRoutines()

# Prompts the user to select a operation to perform
print "Enter a number to perform a math operation"
print "1 Perimeter of a rectangle"
print "2 Perimeter of a circle"
print "3 Area of a rectangle"
print "4 Area of a circle"
print "5 Surface area of a cube"
print "6 Surface area of a cylinder"                                         
print "7 Area of a trapezoid"

selection = raw_input("Please Select a math routine")

# Depending on the users input, a different operation will run
if (selection == "1" or selection == "3"):
    output = DoMath.rec_input(selection)
    
if (selection == "2" or selection == "4"):
    output = DoMath.circ_input(selection)

if (selection == "5"):
    output = DoMath.cube_input()

if (selection == "6"):
    output = DoMath.cyl_input()

if (selection == "7"):
    output = DoMath.trap_input()

# Program is complete, print the answer the math operation    
print "The answer to this equation is: "
print output