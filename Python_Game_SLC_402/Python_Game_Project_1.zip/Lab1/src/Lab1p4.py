'''
    MODULE NAME: First Python Lab, Part 4
    
    FUNCTION:    Allows the user to play a sound file
             
    INPUTS:      keyboard
    
    OUTPUTS:     audio
    
    USAGE:
             The program will first prompt the for which sound file to play
             then prompt the user to fill in the directory of the sound file.
             
    DESIGN NOTES:
        Requirements:
            - prompt the user to name a sound file
            - prompt the user for the location of the file
            - receive the above two via command line
            
        Design:
            - PROMPT USER FOR SOUND FILE NAME
            - PROMPT USER FOR SOUND FILE LOCATION
            - READ IN COMMAND LINE ARGUMENTS AS INPUT
            - PLAY SOUND FILE
            - COMPLETE
            
    Programmed by: Noah Petrides
    Date Completed: January 27 2016
'''

import sys
import os
# Class containing math functions
class part4sound:
    "Game 400 Lab 1 Part 4"
    def playsound(self, location):
        os.system("start " + str(location))
        return
    def getname(self):
        if total_arg >= 3:
            filename = sys.argv[1]
            path = sys.argv[2]
        else:
            print "Not enough arguments passed."
            filename = raw_input("Enter the sound file's name")
            path = raw_input("Enter the full path to the sound file, if the sound file is in the default folder, enter \"default\"")
            
        if path == "default":
            path = os.getcwd()
            
        filepath = path + "\\" + filename
        self.playsound(filepath)
        return

# Construct the object
SoundPlayer = part4sound()

# Total number of arguments passed in the command prompt
total_arg = len(sys.argv)

# Program go!
SoundPlayer.getname()

print "Thanks for using this program! Copyright Noah Petrides St. Lawrence College"
    