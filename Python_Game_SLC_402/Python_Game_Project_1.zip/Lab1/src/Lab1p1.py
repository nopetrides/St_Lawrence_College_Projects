'''
    MODULE NAME: First Python Lab, Part 1
    
    FUNCTION:    Allows the user to do several math functions
             
    INPUTS:      keyboard
    
    OUTPUTS:     screen
    
    USAGE:
             The program will first prompt the user for which
             math operation they would like to perform
             It then gets input for the variables for each
             operation to be performed
             
    DESIGN NOTES:
        Requirements:
            - prompt the user to perform a math operation
            - calculate the answer from inputed variables
            
        Design:
            - PROMPT USER FOR OPERATION TO DO
            - READ USER VARIABLES
            - CALCULATE ANSWER
            - PRINT ANSWER
            - COMPLETE
            
    Programmed by: Noah Petrides
    Date Completed: January 26 2016
'''

pi = 3.14159
def p_o_rec(length, width):
    return 2 * (length+width)

def p_o_circ(radius):
    return 2 * pi * radius

def a_o_rec(length, width):
    return length * width

def a_o_circ(radius):
    return pi * (radius**2)

def sa_o_cube(edge):
    return 6 * (edge**2)

def sa_o_cyl(radius, height):
    return 2 * pi * radius * height + 2 * pi * radius

def a_o_trap(a_base, b_base, height):
    return ((a_base + b_base) /2) * height

# Prompts the user to select a operation to perform
print "Enter a number to perform a math operation"
print "1 Perimeter of a rectangle"
print "2 Perimeter of a circle"
print "3 Area of a rectangle"
print "4 Area of a circle"
print "5 Surface area of a cube"
print "6 Surface area of a cylinder"                                         
print "7 Area of a trapezoid"

selection = raw_input("Please Select a math routine")

def rec_input(selected):
    var1 = raw_input("Enter the length of the rectangle")
    var2 = raw_input("Enter the width of the rectangle")
    if (selected == "1"):
        answer = p_o_rec(float(var1), float(var2))
    if (selected == "3"):
        answer = a_o_rec(float(var1), float(var2))
    return answer

def circ_input(selected):
    var1 = raw_input("Enter the radius of the circle")
    if (selected == "2"):
        answer = p_o_circ(float(var1))
    if (selected == "4"):
        answer = a_o_circ(float(var1))
    return answer

def cube_input():
    var1 = raw_input("Enter the radius of the circle")
    answer = sa_o_cube(float(var1))
    return answer

def cyl_input():
    var1 = raw_input("Enter the radius of the cylinder")
    var2 = raw_input("Enter the height of the cylinder")
    answer = sa_o_cyl(float(var1), float(var2))
    return answer

def trap_input():
    var1 = raw_input("Enter the first base of the trapezoid")
    var2 = raw_input("Enter the second base of the trapezoid")
    var3 = raw_input("Enter the height of the trapezoid")
    answer = a_o_trap(float(var1), float(var2), float(var3))
    return answer

# Depending on the users input, a different operation will run
if (selection == "1" or selection == "3"):
    output = rec_input(selection)
    
if (selection == "2" or selection == "4"):
    output = circ_input(selection)

if (selection == "5"):
    output = cube_input()

if (selection == "6"):
    output = cyl_input()

if (selection == "7"):
    output = trap_input()

# Program is complete, print the answer the math operation    
print "The answer to this equation is: "
print output