'''
    MODULE NAME: Third Python lab - Car doge
    
    FUNCTION:    The user controls a car and their goal is to dodge the other cars, keyboard controls, music, collision with sounds
             
    INPUTS:      keyboard
    
    OUTPUTS:     Images in a window and audio
    
    USAGE:
             The program starts up with a car, the user can move the green car with the arrow keys
             
    DESIGN NOTES:
        Requirements:
            - Allow keyboard control for player image
            - Player must dodge incoming cars
            - Background music and collision sounds
            
        Design:
            - Draw a sprite image to the screen.
            - Play background music
            - Process input from user from keyboard
            - Update screen
            - Play sound on collision
            
    Programmed by: Noah Petrides
    Date Completed: February 24 2016
'''

import pygame
import random
from pygame.constants import RLEACCEL
import os


#Get Current working directory
path = os.getcwd()

#sound file locations
bg1 = path + '\\' + 'Me - The 1975.mp3'
hit = path + '\\' + 'ding.mp3'

#set starting song
music = bg1

#setup pygame mixer
pygame.mixer.init()
hitsound = pygame.mixer.Sound(hit)
pygame.mixer.music.load(music)
pygame.mixer.music.play()

# Define some colors
BLACK = (0, 0, 0)
WHITE = (255, 255, 255)
GREEN = (0, 255, 0)
RED = (255, 0, 0)
move = 0
posx = 0
posy = 0
change_x = 0
change_y = 0
lanes = [140,290,440,590]
global score

#Function for drawing the road background
def bg(count):
    pygame.draw.rect(screen, BLACK, [250,-50, 300, 1400], 300)
    pygame.draw.rect(screen, WHITE, [100, -50, 150, 1400], 20)
    pygame.draw.rect(screen, WHITE, [400, -50, 150, 1400], 20) 
    pygame.draw.line(screen, WHITE, [700, -50], [700, 1400], 20)
    pygame.draw.line(screen, BLACK, [150, -50+count],[650, -50+count], 20)
    pygame.draw.line(screen, BLACK, [150, 50+count],[650, 50+count], 20)
    pygame.draw.line(screen, BLACK, [150, 150+count],[650, 150+count], 20)
    pygame.draw.line(screen, BLACK, [150, 250+count],[650, 250+count], 20)
    pygame.draw.line(screen, BLACK, [150, 350+count],[650, 350+count], 20)
    pygame.draw.line(screen, BLACK, [150, 450+count],[650, 450+count], 20)
    pygame.draw.line(screen, BLACK, [150, 550+count],[650, 550+count], 20)
    pygame.draw.line(screen, BLACK, [150, 650+count],[650, 650+count], 20)
    pygame.draw.line(screen, BLACK, [150, 750+count],[650, 750+count], 20)
    pygame.draw.line(screen, BLACK, [150, 850+count],[650, 850+count], 20)
    
 
#class for the cars
class Block(pygame.sprite.Sprite):
    """
    This class represents the ball
    It derives from the "Sprite" class in Pygame
    """
    def __init__(self, width, height, bspeed):
        """ Constructor. Pass in the color of the block,
        and its x and y position. """
        # Call the parent class (Sprite) constructor
        pygame.sprite.Sprite.__init__(self)
 
        # Create an image of the block, and fill it with a color.
        # This could also be an image loaded from the disk.
        # Set the background color and set it to be transparent
        #self.image = pygame.Surface([width, height])
        #self.image.fill(color)
        self.speed = bspeed
        self.image = pygame.image.load("TopDownEnemy.png").convert()
        
        ####################################################################
        
        # Fetch the rectangle object that has the dimensions of the image
        # image.
        # Update the position of this object by setting the values
        # of rect.x and rect.y
        self.rect = self.image.get_rect()
 
    def reset_pos(self):
        """ Reset position to the top of the screen, at a random x location.
        Called by update() or the main program loop if there is a collision.
        """
        self.rect.y = random.randrange(-900, -200)
        self.rect.x = random.choice(lanes)
        
 
    def update(self):
        """ Called each frame. """
 
        # Move block down one pixel
        self.rect.y += self.speed
 
        # If block is too far down, reset to top of screen.

        
#Class for the player car
class Player(Block):
    """ The player class derives from Block, but overrides the 'update'
    functionality with new a movement function that will move the block
    with the mouse. """
    def __init__(self, color, width, height):
        """ Constructor. Pass in the color of the block,
        and its x and y position. """
        # Call the parent class (Sprite) constructor
        pygame.sprite.Sprite.__init__(self)
 
        # Create an image of the block, and fill it with a color.
        # This could also be an image loaded from the disk.
        # Set the background color and set it to be transparent
        #self.image = pygame.Surface([width, height])
        #self.image.fill(color)

        self.image = pygame.image.load("TopDownPlayer.png").convert()
        self.image.set_colorkey(-1, RLEACCEL)
        ####################################################################
        
        # Fetch the rectangle object that has the dimensions of the image
        # image.
        # Update the position of this object by setting the values
        # of rect.x and rect.y
        self.rect = self.image.get_rect()
    def update(self):
        # Get the current mouse position. This returns the position
        # as a list of two numbers.
        
 
        # Fetch the x and y out of the list,
        # just like we'd fetch letters out of a string.
        # Set the player object to the mouse location
        self.rect.x = 140 + posx
        self.rect.y = 600 + posy
        
        if self.rect.x < 112:
            self.rect.x = 114
        elif self.rect.x > 615:
            self.rect.x = 613
        if self.rect.y < 1:
            self.rect.y = 3
        elif self.rect.y > 750:
            self.rect.y = 748
        
        
        
        
########################### GAME STARTS HERE #############################
# Initialize Pygame
pygame.init()
 
# Set the height and width of the screen
screen_width = 900
screen_height = 900
screen = pygame.display.set_mode([screen_width, screen_height])
 
# This is a list of 'sprites.' Each block in the program is
# added to this list. The list is managed by a class called 'Group.'
block_list = pygame.sprite.Group()
 
# This is a list of every sprite. All blocks and the player block as well.
all_sprites_list = pygame.sprite.Group()
 
for i in range(4):
    # This represents a block
    randmove = random.randrange(3, 10)
    block = Block( 20, 15, randmove)
    # Set a random location for the block
    block.rect.x = random.choice(lanes)
    block.rect.y = random.randrange(-900, -200)
 
    # Add the block to the list of objects
    block_list.add(block)
    all_sprites_list.add(block)
    
 
# Create a red player block
player = Player(RED, 20, 15)
all_sprites_list.add(player)
 
# Loop until the user clicks the close button.
done = False
 
# Used to manage how fast the screen updates
clock = pygame.time.Clock()

# initialize font; must be called after 'pygame.init()' to avoid 'Font not Initialized' error
myfont = pygame.font.SysFont("monospace", 25)

score = 0
 
# -------- Main Program Loop -----------
while not done:
    #---------- Event Processing Loop ----------------
    for event in pygame.event.get():
        if event.type == pygame.QUIT:
            done = True
        elif event.type == pygame.KEYDOWN:
            # Figure out if it was an arrow key. If so
            # adjust speed.
            if event.key == pygame.K_LEFT:
                change_x = -5
            elif event.key == pygame.K_RIGHT:
                change_x = 5
            elif event.key == pygame.K_UP:
                change_y = -5
            elif event.key == pygame.K_DOWN:
                change_y = 5
                
        elif event.type == pygame.KEYUP:
        # If it is an arrow key, reset vector back to zero
            if event.key == pygame.K_LEFT or event.key == pygame.K_RIGHT:
                change_x = 0
            elif event.key == pygame.K_UP or event.key == pygame.K_DOWN:
                change_y = 0
                
                
    # Clear the screen
    screen.fill(GREEN)
    # Draw Background moving
    bg(move)
    move += 5
    if move >= 100:
        move = 0 
    
    posx += change_x
    posy += change_y
    # Calls update() method on every sprite in the list
    all_sprites_list.update() 
    for block in block_list:
        if block.rect.y > 910:
            block.reset_pos()
            score += 1
    # render text
    label = myfont.render("Score: " + str(score), 1, BLACK)
    screen.blit(label, (730, 100))

    # See if the player block has collided with anything.
    blocks_hit_list = pygame.sprite.spritecollide(player, block_list, False)
 
    # Check the list of collisions.
    for block in blocks_hit_list:
        score += -2
        
        hitsound.play()
 
        # Reset block to the top of the screen to fall again.
        block.reset_pos()
        
 
    # Draw all the spites
    all_sprites_list.draw(screen)
 
    # Limit to 60 frames per second
    clock.tick(60)
 
    # Go ahead and update the screen with what we've drawn.
    pygame.display.flip()
 
pygame.quit()