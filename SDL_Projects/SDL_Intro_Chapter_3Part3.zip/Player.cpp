#include <iostream>
#include "Player.h"

Player::Player(const LoaderParams* pParams) :SDLGameObject(pParams)
{
}

void Player::draw()
{
	SDLGameObject::draw(); // we now use SDLGameObject
}

void Player::update(int screen_w, int  screen_h)
{

	if (rev_dir_x)
	{
		if (m_x + m_width >= screen_w)
		{
			rev_dir_x = false;
		}
		else
		{
			m_x += 1;
		}
	}
	else
	{
		if (m_x <= 0)
		{
			rev_dir_x = true;
		}
		else
		{
			m_x -= 1;
		}
	}
	if (rev_dir_y)
	{
		if (m_y + m_height >= screen_h)
		{
			rev_dir_y = false;
		}
		else
		{
			m_y += 1;
		}
	}
	else
	{
		if (m_y <= 0)
		{
			rev_dir_y = true;
		}
		else
		{
			m_y -= 1;
		}
	}

	m_currentFrame = int(((SDL_GetTicks() / 100) % 6));
}

void Player::clean()
{
}
/*
void Player::draw(SDL_Renderer* pRenderer)
{
	GameObject::draw(pRenderer);
}

void Player::update()
{
	//using the fish sprite which has 5 frames
	m_x += 2;

m_currentFrame = int(((SDL_GetTicks() / 100) % 6));
}
*/


