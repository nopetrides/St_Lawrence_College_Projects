#ifndef __Enemy__
#define __Enemy__
#include <iostream>
//#include "GameObject.h"
#include "SDLGameObject.h"


class Enemy : public SDLGameObject
{
public:
	Enemy(const LoaderParams* pParams);
	virtual void draw();
	virtual void update(int screen_w, int  screen_h);
	virtual void clean();
	int r_vel = 0;
};
#endif /* defined(__Game__) */