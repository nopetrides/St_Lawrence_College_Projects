#include <iostream>
#include "Enemy.h"

Enemy::Enemy(const LoaderParams* pParams) :SDLGameObject(pParams)
{
	r_vel = rand() % 10;
}

void Enemy::draw()
{
	SDLGameObject::draw(); // we now use SDLGameObject
}

void Enemy::update(int screen_w, int  screen_h)
{
//	m_x -= 1;
//	m_currentFrame = int(((SDL_GetTicks() / 100) % 6));

	if (rev_dir_x)
	{
		if (m_x + m_width >= screen_w)
		{
			rev_dir_x = false;
		}
		else
		{
			m_x += 1;
		}
	}
	else
	{
		if (m_x <= 0)
		{
			rev_dir_x = true;
		}
		else
		{
			m_x -= 1;
		}
	}
	if (rev_dir_y)
	{
		if (m_y + m_width >= screen_h)
		{
			rev_dir_y = false;
		}
		else
		{
			m_y += r_vel;
		}
	}
	else
	{
		if (m_y <= 0)
		{
			rev_dir_y = true;
		}
		else
		{
			m_y -= r_vel;
		}
	}


	m_currentFrame = int(((SDL_GetTicks() / 100) % 5));

}

void Enemy::clean()
{
}

/*


void Enemy::load(int x, int y, int width, int height, std::string textureID)
{
	GameObject::load(x, y, width, height, textureID);
}

void Enemy::draw(SDL_Renderer* pRenderer)
{
	GameObject::draw(pRenderer);
}

void Enemy::update()
{
	//using the runing cat as the enemy whihc has 6 frames
	m_x += 1;
	m_currentFrame = int(((SDL_GetTicks() / 100) % 5));


}
*/