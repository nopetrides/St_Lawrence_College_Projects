#include <iostream>
#include "Player.h"

Player::Player(const LoaderParams* pParams) :SDLGameObject(pParams)
{
}

void Player::draw()
{
	SDLGameObject::draw(); // we now use SDLGameObject
}

void Player::update()
{
	//m_position.setX(m_position.getX() -1);

	m_currentFrame = int(((SDL_GetTicks() / 100) % 6));
	m_acceleration.setX(-0.1); //page 77

	SDLGameObject::update();
}

void Player::clean()
{
}
/*
void Player::draw(SDL_Renderer* pRenderer)
{
	GameObject::draw(pRenderer);
}

void Player::update()
{
	//using the fish sprite which has 5 frames
	m_x += 2;

m_currentFrame = int(((SDL_GetTicks() / 100) % 6));
}
*/


